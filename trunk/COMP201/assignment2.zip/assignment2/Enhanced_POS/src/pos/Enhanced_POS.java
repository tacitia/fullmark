/**
 * Name: XIAO Sa
 * Student ID: 07592272
 * Acknowledge: 1. Core JAVA
 *              2. Introduction to JAVA Programming
 *              3. www.csdn.net
 */

package pos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;
import conf.GlobalConfiguration;
import conf.discount.CompositeDiscount;
import core.entities.Item;
import core.entities.ItemList;
import core.entities.UserList;

/**
 * <core>Enhanced_POS</core> object provides the graphical user interface for
 * the point of sale(POS) application. It has the following functionalities,
 * including logging in, choosing products and paying for the bill. Moreover,
 * the <core>Enhanced_POS</core> class also records the purchased details into
 * salesRecords.txt file.
 * <p>
 * <core>Enhanced_POS</core> allows different users to use the system at the
 * same time. However, for the same user, he can only log in once at one time.
 * 
 * @author XIAO Sa(07592272)
 * 
 */
public class Enhanced_POS extends JFrame implements Runnable {
	private static final long serialVersionUID = 1L;
	private static GlobalConfiguration conf = GlobalConfiguration.getInstance();
	private static boolean finished = conf.load(null, null, null, null);
	private static ExecutorService executor = Executors.newCachedThreadPool();
	private static Vector<String> userLogin = new Vector<String>();
	private static File salesRecordFile = new File(
			"./configure/salesRecord.txt");

	static {
		if (finished) {
			synchronized (salesRecordFile) {
				if (!salesRecordFile.exists()) {
					try {
						salesRecordFile.createNewFile();
						FileWriter file = new FileWriter(salesRecordFile);
						PrintWriter out = new PrintWriter(file);
						out.println("The format of Sales Record:");
						out.println("Operator VIP Price Discount Paid Refund");
						out.println("Product1 amount, Product2 amount...");
						out.flush();
						file.close();
						out.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

	/**
	 * Constructs a <core>Enhanced_POS</core> object and initialize some
	 * essential data to record the shopping process for users.
	 */
	public Enhanced_POS() {
		// check whether the configuration of system is valid
		if (!finished) {
			Logger.getAnonymousLogger().log(Level.SEVERE,
					"Loading application configuration failed!");
			System.exit(1);
		}

		JButton addButton = new JButton("Add");
		this.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 20));
		this.add(new JLabel("Click to add a new POS"));
		this.add(addButton);

		// register listener to addButton
		addButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				executor.execute(new LoginInterface());
			}

		});
	}

	/**
	 * When an object implementing interface Runnable is used to create a
	 * thread, starting the thread causes the object's run method to be called
	 * in that separately executing thread.
	 */
	@Override
	public void run() {
		// make the Enhanced_POS system visible to user
		this.setSize(350, 100);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	/**
	 * This method is main function to execute the Enhanced_POS system.
	 */
	public static void main(String[] args) {
		executor.execute(new Enhanced_POS());
	}

	// inner class to encapsulate login interface
	private static class LoginInterface extends JFrame implements Runnable {
		private static final long serialVersionUID = 1L;
		private String name = "";
		private String password = "";
		private JTextField nameTextField = new JTextField();
		private JPasswordField passwordTextField = new JPasswordField();
		private JLabel errorMessageLabel = new JLabel("", JLabel.CENTER);

		LoginInterface() {
			// create north panel to display connection info
			JPanel northPanel = new JPanel();
			JLabel connectLabel = new JLabel(
					"Connection Succeed, Please sign in!", JLabel.CENTER);
			connectLabel.setForeground(Color.BLUE);
			northPanel.add(connectLabel);
			northPanel.setPreferredSize(new Dimension(400, 20));

			// create a center panel to get user info
			JPanel centerPanel = new JPanel();
			JButton loginButton = new JButton("Sign In");
			centerPanel.setLayout(new GridLayout(3, 2, 5, 5));
			centerPanel.add(new JLabel("User Name:", JLabel.RIGHT));
			centerPanel.add(nameTextField);
			centerPanel.add(new JLabel("Password:", JLabel.RIGHT));
			centerPanel.add(passwordTextField);
			centerPanel.add(new JLabel(""));
			centerPanel.add(loginButton);
			centerPanel.setBorder(BorderFactory.createRaisedBevelBorder());

			// create south panel to display login info
			JPanel southPanel = new JPanel();
			errorMessageLabel.setForeground(Color.RED);
			southPanel.add(errorMessageLabel);
			southPanel.setPreferredSize(new Dimension(400, 20));

			// set layout of frame to display login user interface
			setLayout(new BorderLayout(0, 10));
			add(northPanel, BorderLayout.NORTH);
			add(centerPanel, BorderLayout.CENTER);
			add(southPanel, BorderLayout.SOUTH);

			// register listener to loginButton
			loginButton.addActionListener(new ActionListener() {

				@SuppressWarnings("deprecation")
				@Override
				public void actionPerformed(ActionEvent e) {
					name = nameTextField.getText().trim();
					password = passwordTextField.getText();
					// check whether the username and password is valid or not
					if (UserList.getInstance().isInitialized()
							&& !UserList.getInstance().verifyUser(name,
									password)) {
						errorMessageLabel
								.setText("Invalid username and password!");
					} else {
						// make sure only one thread access the userLogin vector
						// at one time
						synchronized (userLogin) {
							for (int i = 0; i < userLogin.size(); i++) {
								if (userLogin.elementAt(i).equals(name)) {
									errorMessageLabel.setText("Operator "
											+ name + " already logged in!");
									return;
								}
							}
							Logger.getAnonymousLogger().log(Level.INFO,
									"Operator " + name + " logged in!");
							userLogin.add(name);
							executor.execute(new SelectInterface(name));
							dispose();
						}
					}
				}
			});
		}

		@Override
		public void run() {
			// make the login interface visible and run for user
			this.setTitle("POS");
			this.setSize(400, 200);
			this.setLocationRelativeTo(null);
			this.setVisible(true);
		}
	}

	// inner class to encapsulate select interface
	private static class SelectInterface extends JFrame implements Runnable {
		private static final long serialVersionUID = 1L;
		private static HashMap<String, Item> items;
		private static DefaultListModel productModel = new DefaultListModel();
		private Vector<Item> shoppingCart = new Vector<Item>();
		private Vector<Integer> shoppingNum = new Vector<Integer>();
		private DefaultListModel shoppingModel = new DefaultListModel();
		private JTextField idTextField = new JTextField(8);
		private JTextField amountTextField1 = new JTextField(6);
		private JTextField amountTextField2 = new JTextField(7);
		private JList productList = new JList(productModel);
		private JList shoppingList = new JList(shoppingModel);
		private JLabel errorMessageLabel = new JLabel("", JLabel.CENTER);
		private JLabel loginMessageLabel = new JLabel("", JLabel.CENTER);
		private JCheckBox vipCheckBox = new JCheckBox();
		private String username = "";
		private boolean isVIP = false;
		private double totalSum = 0;
		private double totalPrice = 0;

		static {
			if (ItemList.getInstance().isInitialized()) {
				items = ItemList.getInstance().getItems();
			} else {
				System.out.println("Error need to be handled in ItemList "
						+ "class!");
				System.exit(0);
			}
			Object[] names = items.values().toArray();

			// initialize the shopping list for users to see
			for (int i = 0; i < names.length; i++) {
				productModel.addElement(((Item) names[i]).getItemName());
			}
		}

		SelectInterface(String _username) {
			username = _username;

			// create loginMessagePanel
			JPanel loginMessagePanel = new JPanel();
			loginMessageLabel.setText("Electronic-Sales"
					+ " Counter is started successfully by user " + username
					+ "!");
			loginMessageLabel.setForeground(Color.BLUE);
			loginMessagePanel.add(loginMessageLabel);
			loginMessagePanel.setPreferredSize(new Dimension(500, 30));

			// create addPanel1
			JPanel addPanel1 = new JPanel();
			addPanel1.setLayout(new FlowLayout());
			JLabel idLabel = new JLabel("ID:");
			JLabel amountLabel1 = new JLabel("Amount:");
			JButton addButton = new JButton("Add");
			amountTextField1.setDocument(new PlainDocument() {
				private static final long serialVersionUID = 1L;

				// check whether the input data is integer or not
				public void insertString(int offset, String s,
						AttributeSet attributeSet) throws BadLocationException {
					try {
						Integer.parseInt(s);
					} catch (Exception ex) {
						Toolkit.getDefaultToolkit().beep();
						return;
					}
					super.insertString(offset, s, attributeSet);
				}
			});
			addPanel1.add(idLabel);
			addPanel1.add(idTextField);
			addPanel1.add(amountLabel1);
			addPanel1.add(amountTextField1);
			addPanel1.add(addButton);
			addPanel1.setBorder(BorderFactory.createRaisedBevelBorder());

			// create northPanel
			JPanel northPanel = new JPanel();
			northPanel.setLayout(new BorderLayout());
			northPanel.add(loginMessagePanel, BorderLayout.NORTH);
			northPanel.add(addPanel1, BorderLayout.SOUTH);

			// create productPanel
			JPanel productPanel = new JPanel();
			Border etched = BorderFactory.createEtchedBorder();
			Border productTitled = BorderFactory.createTitledBorder(etched,
					"Select Products:");
			productPanel.setLayout(new BorderLayout());
			productList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			productPanel.add(productList, BorderLayout.CENTER);
			productPanel.setBorder(productTitled);
			productPanel.setPreferredSize(new Dimension(170, 250));

			// create addPanel2
			JPanel addPanel2 = new JPanel();
			JLabel amountLabel2 = new JLabel("Amount:", JLabel.CENTER);
			JButton rightArrowButton = new JButton("-->");
			JButton leftArrowButton = new JButton("<--");
			JButton clearButton = new JButton("Clear");
			amountLabel2.setPreferredSize(new Dimension(80, 25));
			leftArrowButton.setPreferredSize(new Dimension(80, 25));
			rightArrowButton.setPreferredSize(new Dimension(80, 25));
			clearButton.setPreferredSize(new Dimension(80, 25));
			amountTextField2.setDocument(new PlainDocument() {
				private static final long serialVersionUID = 1L;

				// only integer can be typed in
				public void insertString(int offset, String s,
						AttributeSet attributeSet) throws BadLocationException {
					try {
						Integer.parseInt(s);
					} catch (Exception ex) {
						Toolkit.getDefaultToolkit().beep();
						return;
					}
					super.insertString(offset, s, attributeSet);
				}
			});
			addPanel2.setLayout(new FlowLayout());
			addPanel2.add(amountLabel2);
			addPanel2.add(amountTextField2);
			addPanel2.add(rightArrowButton);
			addPanel2.add(leftArrowButton);
			addPanel2.add(clearButton);

			// create shoppingCartPanel
			JPanel shoppingCartPanel = new JPanel();
			Border cartTitled = BorderFactory.createTitledBorder(etched,
					"Shopping Cart:");
			shoppingCartPanel.setLayout(new BorderLayout());
			shoppingList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			shoppingCartPanel.add(shoppingList);
			shoppingCartPanel.setBorder(cartTitled);
			shoppingCartPanel.setPreferredSize(new Dimension(170, 250));

			// create centerPanel
			JPanel centerPanel = new JPanel();
			centerPanel.setLayout(new BorderLayout());
			centerPanel.add(productPanel, BorderLayout.WEST);
			centerPanel.add(addPanel2, BorderLayout.CENTER);
			centerPanel.add(shoppingCartPanel, BorderLayout.EAST);

			// create vipPanel
			JPanel vipPanel = new JPanel();
			vipPanel.setLayout(new FlowLayout());
			JLabel vipLabel = new JLabel("Is VIP?");
			JButton payButton = new JButton("Pay");
			vipPanel.add(vipLabel);
			vipPanel.add(vipCheckBox);
			vipPanel.add(payButton);
			vipPanel.setBorder(BorderFactory.createRaisedBevelBorder());

			// create errorMessagePanel
			JPanel errorMessagePanel = new JPanel();
			errorMessageLabel.setForeground(Color.RED);
			errorMessagePanel.add(errorMessageLabel);
			errorMessagePanel.setPreferredSize(new Dimension(500, 30));

			// create southPanel
			JPanel southPanel = new JPanel();
			southPanel.setLayout(new BorderLayout());
			southPanel.add(vipPanel, BorderLayout.NORTH);
			southPanel.add(errorMessagePanel, BorderLayout.SOUTH);

			this.setLayout(new BorderLayout());
			this.add(northPanel, BorderLayout.NORTH);
			this.add(centerPanel, BorderLayout.CENTER);
			this.add(southPanel, BorderLayout.SOUTH);

			// register ActionListner to addButton
			addButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					String productID = idTextField.getText();
					String num = amountTextField1.getText();

					// check whether the number is zero
					if (num.matches("0*")) {
						errorMessageLabel.setText("Please input valid "
								+ "product ID and amount");
						return;
					}
					// check whether the productID exists
					if (!items.containsKey(productID)) {
						errorMessageLabel.setText("Product " + productID
								+ " does not exist");
						return;
					}
					// remove the product if it's in shopping cart
					for (int i = 0; i < shoppingCart.size(); i++) {
						if (shoppingCart.elementAt(i).getItemID().equals(
								productID)) {
							shoppingModel.remove(i);
							shoppingCart.remove(i);
							shoppingNum.remove(i);
						}
					}
					double subPrice = items.get(productID).getPrice()
							* Double.valueOf(num);
					BigDecimal subBigDecimal = new BigDecimal(subPrice);
					subPrice = subBigDecimal.setScale(2,
							BigDecimal.ROUND_HALF_UP).doubleValue();
					shoppingCart.add(items.get(productID));
					shoppingNum.add(Integer.valueOf(num));
					shoppingModel.addElement(items.get(productID).getItemName()
							+ " " + Integer.valueOf(num) + " ("
							+ conf.getCurrency().show() + " " + subPrice + ")");
				}
			});

			// register ActionListner to rightArrowButton
			rightArrowButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					int index = productList.getSelectedIndex();
					String num = amountTextField2.getText();
					Object[] tempItem = items.values().toArray();

					// check whether the num is zero
					if (num.matches("0*")) {
						errorMessageLabel.setText("Please input correct "
								+ "amount");
						return;
					}
					// check whether the user selects product
					if (index == -1) {
						errorMessageLabel.setText("Please select product");
						return;
					}
					// remove product if it's in shopping cart
					for (int i = 0; i < shoppingCart.size(); i++) {
						if (shoppingCart.get(i).getItemID().equals(
								((Item) tempItem[index]).getItemID())) {
							shoppingModel.remove(i);
							shoppingCart.remove(i);
							shoppingNum.remove(i);
							break;
						}
					}
					double subPrice = ((Item) tempItem[index]).getPrice()
							* Double.valueOf(num);
					BigDecimal subBigDecimal = new BigDecimal(subPrice);
					subPrice = subBigDecimal.setScale(2,
							BigDecimal.ROUND_HALF_UP).doubleValue();
					shoppingCart.add((Item) tempItem[index]);
					shoppingNum.add(Integer.valueOf(num));
					shoppingModel.addElement(((Item) tempItem[index])
							.getItemName()
							+ " "
							+ Integer.valueOf(num)
							+ " ("
							+ conf.getCurrency().show() + " " + subPrice + ")");
				}

			});

			// register ActionListener to leftArrowButton
			leftArrowButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					int index = shoppingList.getSelectedIndex();

					// put the products selected by user into shopping cart
					if (index == -1) {
						errorMessageLabel
								.setText("Please select in the shopping cart");
						return;
					} else {
						shoppingModel.remove(index);
						shoppingCart.remove(index);
						shoppingNum.remove(index);
					}
				}

			});

			// register ActionListenr to clearButton
			clearButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					// remove all the products in shopping cart
					shoppingModel.removeAllElements();
					shoppingCart.removeAllElements();
					shoppingNum.removeAllElements();
				}

			});

			// register ActionLisner to payButton
			payButton.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// check whether there is at least one product in shopping
					// cart
					if (shoppingModel.size() == 0) {
						errorMessageLabel.setText("Invalid sales information");
						return;
					}
					totalSum = 0;
					totalPrice = 0;
					isVIP = vipCheckBox.isSelected();

					// calculate the totoalPrice and totalSum for bill
					for (int i = 0; i < shoppingModel.size(); i++) {
						totalPrice += shoppingCart.get(i).getPrice()
								* shoppingNum.get(i);
						if (shoppingCart.get(i).getDiscount() != null) {
							totalSum += shoppingCart.get(i).getPrice()
									* shoppingNum.get(i)
									* (1.0 - shoppingCart.get(i).getDiscount()
											.discount());
						} else {
							totalSum += shoppingCart.get(i).getPrice()
									* shoppingNum.get(i);
						}
					}
					CompositeDiscount discount = conf.getGlobalDiscount();
					totalSum = totalSum * (1 - discount.discount(isVIP));
					BigDecimal priceBigDecimal = new BigDecimal(totalPrice);
					BigDecimal sumBigDecimal = new BigDecimal(totalSum);
					totalPrice = priceBigDecimal.setScale(2,
							BigDecimal.ROUND_HALF_UP).doubleValue();
					totalSum = sumBigDecimal.setScale(2,
							BigDecimal.ROUND_HALF_UP).doubleValue();
					setVisible(false);

					// create a interface for user to pay for bill
					PayInterface frame = new PayInterface();

					// register window listener to frame
					frame.addWindowListener(new WindowAdapter() {

						@Override
						public void windowClosed(WindowEvent e) {
							// set select window visible when the payment is
							// finished
							loginMessageLabel
									.setText("Record sales information succeeded!");
							idTextField.setText(null);
							amountTextField1.setText(null);
							amountTextField2.setText(null);
							productList.clearSelection();
							errorMessageLabel.setText(null);
							if (vipCheckBox.isSelected()) {
								vipCheckBox.doClick();
							}
							shoppingModel.removeAllElements();
							shoppingCart.removeAllElements();
							shoppingNum.removeAllElements();
							setVisible(true);
						}

						@Override
						public void windowClosing(WindowEvent e) {
							// log out is the user does not pay for the bill
							synchronized (userLogin) {
								userLogin.remove(username);
								Logger.getAnonymousLogger()
										.log(
												Level.INFO,
												"Operator " + username
														+ " logged out!");
							}
							dispose();
						}

					});
					executor.execute(frame);
				}

			});
		}

		@Override
		public void run() {
			this.setTitle("POS");
			this.setSize(500, 400);
			this.setLocationRelativeTo(null);
			this.addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(WindowEvent e) {
					synchronized (userLogin) {
						userLogin.remove(username);
						Logger.getAnonymousLogger().log(Level.INFO,
								"Operator " + username + " logged out!");
					}
					dispose();
				}
			});
			this.setVisible(true);
		}

		// inner class to encapsulate pay interface
		private class PayInterface extends JFrame implements Runnable {
			private static final long serialVersionUID = 1L;
			JTextField sumTextField = new JTextField();
			JTextField discountedTextField = new JTextField();
			private JTextField paidTextField = new JTextField();
			private JTextField refundTextField = new JTextField();
			private JLabel errorMessageLabel = new JLabel();

			PayInterface() {
				// create northPanel
				JPanel northPanel = new JPanel();
				JLabel payLabel = new JLabel("Please pay the following:",
						JLabel.CENTER);
				payLabel.setForeground(Color.BLUE);
				northPanel.add(payLabel);
				northPanel.setPreferredSize(new Dimension(400, 30));

				// create shoppingCartPanel
				JPanel shoppingCartPanel = new JPanel();
				JTextArea cartArea = new JTextArea();
				String list = "";
				for (int i = 0; i < shoppingCart.size(); i++) {
					list += shoppingCart.elementAt(i).getItemName() + " "
							+ shoppingNum.elementAt(i) + "\n";
				}
				cartArea.setText(list);
				cartArea.setEnabled(false);
				shoppingCartPanel.setLayout(new BorderLayout());
				shoppingCartPanel.add(cartArea);
				shoppingCartPanel.setBorder(BorderFactory.createEtchedBorder());
				shoppingCartPanel.setPreferredSize(new Dimension(100, 300));

				// create pricePanel
				JPanel pricePanel = new JPanel();
				String currency = conf.getCurrency().show();
				JLabel priceLabel = new JLabel("Total Price: " + currency,
						JLabel.RIGHT);
				JLabel discountedLabel = new JLabel("Discounted: " + currency,
						JLabel.RIGHT);
				JLabel sumLabel = new JLabel("Total Sum: " + currency,
						JLabel.RIGHT);
				JLabel paidLabel = new JLabel("Paid: " + currency, JLabel.RIGHT);
				JLabel refundLabel = new JLabel("Refund: " + currency,
						JLabel.RIGHT);
				JTextField priceTextField = new JTextField();
				priceTextField.setText(Double.toString(totalPrice));
				priceTextField.setEnabled(false);
				double discounted = totalPrice - totalSum;
				BigDecimal discountedBigDecimal = new BigDecimal(discounted);
				discountedTextField.setText(Double
						.toString((discountedBigDecimal.setScale(2,
								BigDecimal.ROUND_HALF_UP).doubleValue())));
				discountedTextField.setEnabled(false);
				sumTextField.setText(Double.toString(totalSum));
				sumTextField.setEnabled(false);

				// make sure that only positive valid float can be type in
				paidTextField.setDocument(new PlainDocument() {

					private static final long serialVersionUID = 1L;
					int maxLength = Integer.MAX_VALUE;
					int decLength = Integer.MAX_VALUE;
					double minRange = 0;
					double maxRange = Double.MAX_VALUE;

					public void insertString(int offset, String s,
							AttributeSet a) throws BadLocationException {
						int len = getLength();
						String str = getText(0, len);
						int decPos = str.indexOf(".");
						if (s.equals(" ")
								|| s.equals("F")
								|| s.equals("f")
								|| s.equals("D")
								|| s.equals("d")
								|| (str + s).length() > maxLength
								|| (decPos > -1 && offset > decPos && ((str
										.substring(decPos + 1)) + s).length() > decLength)
								|| (s.equals(".") && decLength == 0)
								|| (s.indexOf(".") > -1 && s.substring(
										s.indexOf(".") + 1).length() > decLength)) {
							Toolkit.getDefaultToolkit().beep();
							return;
						}
						try {
							str = str.substring(0, offset) + s
									+ str.substring(offset, len);
							if (!str.equals("-")
									|| (str.equals("-") && minRange <= 0)) {
								double d = Double.parseDouble(str);
								if (d < minRange || d > maxRange) {
									throw new Exception();
								}
								double refund = d - totalSum;
								BigDecimal refundBigDecimal = new BigDecimal(
										refund);
								refund = refundBigDecimal.setScale(2,
										BigDecimal.ROUND_HALF_UP).doubleValue();
								if (refund < 0) {
									refundTextField.setText("-");
								} else {
									refundTextField.setText(Double
											.toString(refund));
								}
							}
						} catch (Exception e) {
							Toolkit.getDefaultToolkit().beep();
							return;
						}
						super.insertString(offset, s, a);
					}
				});
				paidTextField.addKeyListener(new KeyAdapter() {
					public void keyReleased(KeyEvent e) {
						String tempPay = paidTextField.getText();
						if (tempPay == null || tempPay.equals("")) {
							refundTextField.setText("-");
							return;
						}
						if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE
								|| e.getKeyCode() == KeyEvent.VK_DELETE) {
							double d = Double.parseDouble(tempPay);
							double refund = d - totalSum;
							BigDecimal refundBigDecimal = new BigDecimal(refund);
							refund = refundBigDecimal.setScale(2,
									BigDecimal.ROUND_HALF_UP).doubleValue();
							if (refund < 0) {
								refundTextField.setText("-");
							} else {
								refundTextField
										.setText(Double.toString(refund));
							}
						}
					}
				});
				paidTextField.setText("0.0");
				refundTextField.setText("-");
				refundTextField.setEnabled(false);
				pricePanel.setLayout(new GridLayout(5, 2));
				pricePanel.add(priceLabel);
				pricePanel.add(priceTextField);
				pricePanel.add(discountedLabel);
				pricePanel.add(discountedTextField);
				pricePanel.add(sumLabel);
				pricePanel.add(sumTextField);
				pricePanel.add(paidLabel);
				pricePanel.add(paidTextField);
				pricePanel.add(refundLabel);
				pricePanel.add(refundTextField);
				pricePanel.setBorder(BorderFactory.createEtchedBorder());
				pricePanel.setPreferredSize(new Dimension(250, 160));

				// create outerPricePanel
				JPanel outerPricePanel = new JPanel();
				outerPricePanel.add(pricePanel);

				// create submitPanel
				JPanel submitPanel = new JPanel();
				JButton submitButton = new JButton("Submit");
				submitPanel.add(submitButton);
				submitPanel.setBorder(BorderFactory.createEtchedBorder());

				// create payPanel
				JPanel payPanel = new JPanel();
				payPanel.setLayout(new BorderLayout());
				payPanel.add(outerPricePanel, BorderLayout.CENTER);
				payPanel.add(submitPanel, BorderLayout.SOUTH);

				// create centerPanel
				JPanel centerPanel = new JPanel();
				centerPanel.setLayout(new BorderLayout());
				centerPanel.add(shoppingCartPanel, BorderLayout.WEST);
				centerPanel.add(payPanel, BorderLayout.CENTER);
				centerPanel.setBorder(BorderFactory.createRaisedBevelBorder());

				// create southPanel
				JPanel southPanel = new JPanel();
				errorMessageLabel.setForeground(Color.RED);
				southPanel.add(errorMessageLabel);
				southPanel.setPreferredSize(new Dimension(400, 30));

				this.setLayout(new BorderLayout());
				this.add(northPanel, BorderLayout.NORTH);
				this.add(centerPanel, BorderLayout.CENTER);
				this.add(southPanel, BorderLayout.SOUTH);

				// register ActionListner to submitButton
				submitButton.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent arg0) {
						String discounted = discountedTextField.getText();
						String pay = paidTextField.getText();
						String sum = sumTextField.getText();
						double offset = 0;

						if (pay == null || pay.equals("")) {
							offset = -1;
						} else {
							offset = Double.valueOf(pay) - Double.valueOf(sum);
						}
						BigDecimal offsetBigDecimal = new BigDecimal(offset);
						offset = offsetBigDecimal.setScale(2,
								BigDecimal.ROUND_HALF_UP).doubleValue();
						double payValue = Double.parseDouble(pay);
						BigDecimal payBigDecimal = new BigDecimal(payValue);
						payValue = payBigDecimal.setScale(2,
								BigDecimal.ROUND_HALF_UP).doubleValue();

						// check whether the pay money is enough or not
						if (offset < 0) {
							errorMessageLabel.setText("Not enough money!");
							return;
						} else {
							synchronized (salesRecordFile) {
								if (!salesRecordFile.exists()) {
									try {
										salesRecordFile.createNewFile();
									} catch (IOException e) {
										e.printStackTrace();
									}
								}
								try {
									FileWriter file = new FileWriter(
											salesRecordFile, true);
									PrintWriter out = new PrintWriter(file);
									out.println("\n\nPurchase:");
									out.println(username + " " + isVIP + " "
											+ totalPrice + " " + discounted
											+ " " + payValue + " " + offset);

									for (int i = 0; i < shoppingCart.size(); i++) {
										Item tempItem = shoppingCart
												.elementAt(i);
										String tempProductID = tempItem
												.getItemID();
										String tempAmount = Integer
												.toString(shoppingNum
														.elementAt(i));
										out.print(tempProductID + " "
												+ tempAmount + ",");
										out.flush();
									}
									file.close();
									out.close();
									Logger.getAnonymousLogger().log(Level.INFO,
											"Sales recorded by " + username);
								} catch (IOException e) {
									e.printStackTrace();
								}
								dispose();
							}
						}
					}
				});
			}

			@Override
			public void run() {
				this.setTitle("POS");
				this.setSize(400, 360);
				this.setLocationRelativeTo(null);
				this.setVisible(true);
			}
		}
	}
}
