package conf.discount;

public interface Discount {
	public float discount();
	public String discountMessage();
	public String type();
}
