package conf.currency;

public class HKCurrency extends Currency {
	public String show() {
		return "HK$";
	}
}
