package conf.currency;

public class USCurrency extends Currency{
	public String show() {
		return "US$";
	}
}
