package conf.currency;

public abstract class Currency {
	public abstract String show();
}
