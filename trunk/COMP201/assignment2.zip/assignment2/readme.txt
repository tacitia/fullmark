Name: XIAO Sa
Student ID: 07592272
Lab Section: LA1A
Acknowledagement:
1. Core Java
2. Introduction to Java Programming
3. www.csdn.net


Files contains:
1. Enhanced_POS: including the original project
2. Demo: including configure file and also a runnable JAR file.


