/*
Name: XIAO Sa
Student ID: 07592272
Lab Section: LA1A
Group Member: GUO Hua, 07621140, LA1B
*/


DROP TRIGGER check_service_MaxNum_BB;

DROP TRIGGER check_service_MaxNum_HT;
DROP TRIGGER check_credit_card_info;

DROP TRIGGER check_unique_BB_id;

DROP TRIGGER check_unique_HT_id;
DROP TRIGGER check_BB_type;
DROP TRIGGER check_HT_type;
DROP TRIGGER BB_subscription_delete_cascade;
DROP TRIGGER HT_subscription_delete_cascade;
DROP TABLE BB_plan_subscriptions;
DROP TABLE HT_plan_subscriptions;
DROP TABLE service_plans;
DROP TABLE customers;