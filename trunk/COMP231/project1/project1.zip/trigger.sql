/*
Name: XIAO Sa
Student ID: 07592272
Lab Section: LA1A
Group Member: GUO Hua, 07621140, LA1B
*/

CREATE OR REPLACE TRIGGER check_service_MaxNum_BB
BEFORE INSERT OR UPDATE OF hkid ON BB_plan_subscriptions
FOR EACH ROW
DECLARE
	i NUMBER(1):= 0;
BEGIN
	FOR R1 IN (
		SELECT * FROM BB_plan_subscriptions
		)LOOP
			IF :NEW.hkid = R1.hkid THEN
				i:= i + 1;
			END IF;
		END LOOP;
	FOR R2 IN (
		SELECT * FROM HT_plan_subscriptions
		)LOOP	
			IF :NEW.hkid = R2.hkid THEN
				i:= i + 1;
			END IF;
		END LOOP;
	IF i >= 3 THEN
		raise_application_error(-20000, 'Each customer can only subscribe at most three service plans!');
	END IF;
END;
/

CREATE OR REPLACE TRIGGER check_service_MaxNum_HT
BEFORE INSERT OR UPDATE OF hkid ON HT_plan_subscriptions
FOR EACH ROW
DECLARE
	i NUMBER(1):= 0;
BEGIN
	FOR R1 IN (
		SELECT * FROM BB_plan_subscriptions
		)LOOP
			IF :NEW.hkid = R1.hkid THEN
				i:= i + 1;
			END IF;
		END LOOP;
	FOR R2 IN (
		SELECT * FROM HT_plan_subscriptions
		)LOOP	
			IF :NEW.hkid = R2.hkid THEN
				i:= i + 1;
			END IF;
		END LOOP;
	IF i >= 3 THEN
		raise_application_error(-20000, 'Each customer can only subscribe at most three service plans!');
	END IF;
END;
/

CREATE OR REPLACE TRIGGER check_credit_card_info
BEFORE INSERT OR UPDATE OF payment_method, card_number, card_owner, card_expiry_date ON customers
FOR EACH ROW
BEGIN
	IF :NEW.payment_method = 'auto-pay' THEN
		IF (
		:NEW.card_number is NULL OR
		:NEW.card_owner is NULL OR
		:NEW.card_expiry_date is NULL
		) THEN 
			raise_application_error(-20001, 'Missing credit card information');
		END IF;
	END IF;
	IF :NEW.payment_method = 'cash' THEN
		IF (
		:NEW.card_number is not NULL OR
		:NEW.card_owner is not NULL OR
		:NEW.card_expiry_date is not NULL
		) THEN
			raise_application_error(-20002, 'Extra card_number, card_owner and card_expiry_date information for cash payment');
		END IF;
	END IF;
END;
/

CREATE OR REPLACE TRIGGER check_unique_BB_id
BEFORE INSERT OR UPDATE OF subscription_id ON BB_plan_subscriptions
FOR EACH ROW
BEGIN
	FOR R IN (
	SELECT * FROM HT_plan_subscriptions
	)LOOP
		IF :NEW.subscription_id = R.subscription_id THEN
			raise_application_error(-20003, 'BB plan subscriptions can not have the same id as HT plan subscriptions');
		END IF;
	END LOOP;
END;
/

CREATE OR REPLACE TRIGGER check_unique_HT_id
BEFORE INSERT OR UPDATE OF subscription_id ON HT_plan_subscriptions
FOR EACH ROW
BEGIN
	FOR R IN (
	SELECT * FROM BB_plan_subscriptions
	)LOOP
		IF :NEW.subscription_id = R.subscription_id THEN
			raise_application_error(-20004, 'HT plan subscriptions can not have the same id as BB plan subscriptions');
		END IF;
	END LOOP;
END;
/

CREATE OR REPLACE TRIGGER check_BB_type
BEFORE INSERT OR UPDATE OF plan_code ON BB_plan_subscriptions
FOR EACH ROW
BEGIN
	FOR R IN (
	SELECT * FROM service_plans
	)LOOP
		IF :NEW.plan_code = R.plan_code AND R.service_type = 'HT' THEN
			raise_application_error(-20005, 'BB plan subscription must belong to service plan whose service type is BB');
		END IF;
	END LOOP;
END;
/

CREATE OR REPLACE TRIGGER check_HT_type
BEFORE INSERT OR UPDATE OF plan_code ON HT_plan_subscriptions
FOR EACH ROW
BEGIN
	FOR R IN (
	SELECT * FROM service_plans
	)LOOP
		IF :NEW.plan_code = R.plan_code AND R.service_type = 'BB' THEN
			raise_application_error(-20006, 'HT plan subscription must belong to service plan whose service type is HT');
		END IF;
	END LOOP;
END;
/


CREATE OR REPLACE TRIGGER BB_subscription_delete_cascade
AFTER DELETE ON BB_plan_subscriptions
DECLARE
	isExist BOOLEAN:= FALSE;
BEGIN
	FOR R IN (
		SELECT hkid FROM customers
		) LOOP
			isExist := FALSE;
			FOR R1 IN(
				SELECT * from BB_plan_subscriptions
				) LOOP
					IF R1.hkid = R.hkid THEN
					isExist := TRUE;
					END IF;
				END LOOP;
			FOR R2 IN(
				SELECT * FROM HT_plan_subscriptions
				) LOOP
					IF R2.hkid = R.hkid THEN
					isExist := TRUE;
					END IF;
				END LOOP;
			IF NOT isExist THEN
				DELETE FROM customers
				WHERE customers.hkid = R.hkid;
			END IF;
		END LOOP;		
END;
/


CREATE OR REPLACE TRIGGER HT_subscription_delete_cascade
AFTER DELETE ON HT_plan_subscriptions
DECLARE
	isExist BOOLEAN:= FALSE;
BEGIN
	FOR R IN (
		SELECT hkid FROM customers
		) LOOP
			isExist := FALSE;
			FOR R1 IN(
				SELECT * from BB_plan_subscriptions
				) LOOP
					IF R1.hkid = R.hkid THEN
					isExist := TRUE;
					END IF;
				END LOOP;
			FOR R2 IN(
				SELECT * FROM HT_plan_subscriptions
				) LOOP
					IF R2.hkid = R.hkid THEN
					isExist := TRUE;
					END IF;
				END LOOP;
			IF not isExist THEN
				DELETE FROM customers
				WHERE customers.hkid = R.hkid;
			END IF;
		END LOOP;		
END;
/